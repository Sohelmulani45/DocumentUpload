﻿using System.ComponentModel.DataAnnotations;

namespace UserIPAddress.BLL.DTOs
{
    public class UserCreateDto
    {
        [Required(ErrorMessage = "User name is required")]
        [StringLength(100, ErrorMessage = "User name cannot exceed 100 characters")]
        public string UserName { get; set; } = null!;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [StringLength(200, ErrorMessage = "Email cannot exceed 200 characters")]
        public string EmailId { get; set; } = null!;

        [Required(ErrorMessage = "Password is required")]
        [StringLength(500, MinimumLength = 6, ErrorMessage = "Password must be 6-500 characters")]
        public string Password { get; set; } = null!;

        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }

        [Required(ErrorMessage = "At least one IP address is required")]
        public string IpList { get; set; } = null!;  // "192.168.0.1,192.168.0.2"
    }
}
