﻿namespace UserIPAddress.BLL.DTOs
{
    public class UserDetailDto
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = null!;
        public string EmailId { get; set; } = null!;
        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<string> IpAddresses { get; set; } = new();
    }
}
