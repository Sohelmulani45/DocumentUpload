﻿using System.Text.Json.Serialization;

namespace UserIPAddress.BLL.DTOs
{
    public class UserDto
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = null!;
        public string EmailId { get; set; } = null!;
        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }
        public string AllowedIps { get; set; } = null!;
    }
}
