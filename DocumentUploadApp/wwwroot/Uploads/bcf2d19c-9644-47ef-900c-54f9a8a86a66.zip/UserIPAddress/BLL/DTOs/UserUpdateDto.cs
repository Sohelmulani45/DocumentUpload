﻿using System.ComponentModel.DataAnnotations;

namespace UserIPAddress.BLL.DTOs
{
    public class UserUpdateDto
    {
        [Required]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string EmailId { get; set; } = null!;

        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }

        [Required(ErrorMessage = "At least one IP address is required")]
        public string IpList { get; set; } = null!;  // "192.168.0.1,192.168.0.2"
    }
}
