﻿using Microsoft.AspNetCore.Identity;  // Ye add karo
using UserIPAddress.BLL.DTOs;
using UserIPAddress.BLL.Services.Interfaces;
using UserIPAddress.DAL.Models;
using UserIPAddress.DAL.Repository.Interfaces;

namespace UserIPAddress.BLL.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IPasswordHasher<User> _passwordHasher;  // Ye add karo

        public UserService(IUserRepository userRepository, IPasswordHasher<User> passwordHasher)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;  // Constructor me add karo
        }

        public async Task<int> CreateUserAsync(UserCreateDto dto)
        {
            // Password hash karo (Identity use karke)
            var tempUser = new User { UserName = dto.UserName };  // Temporary user
            string passwordHash = _passwordHasher.HashPassword(tempUser, dto.Password);

            // IP list ko validate karo (comma-separated, non-empty)
            var ipList = dto.IpList.Split(',')
                                 .Where(ip => !string.IsNullOrWhiteSpace(ip))
                                 .Select(ip => ip.Trim())
                                 .ToList();

            if (!ipList.Any())
                throw new ArgumentException("At least one valid IP address is required");

            // User entity banao
            var user = new User
            {
                UserName = dto.UserName,
                EmailId = dto.EmailId,
                PasswordHash = passwordHash,
                BirthDate = dto.BirthDate,
                Address = dto.Address
            };

            // DAL call karo
            return await _userRepository.CreateAsync(user, ipList);
        }

        // Baaki methods same rahenge...
        public async Task UpdateUserAsync(UserUpdateDto dto)
        {
            // IP list validate
            var ipList = dto.IpList.Split(',')
                                 .Where(ip => !string.IsNullOrWhiteSpace(ip))
                                 .Select(ip => ip.Trim())
                                 .ToList();

            if (!ipList.Any())
                throw new ArgumentException("At least one valid IP address is required");

            // User entity banao
            var user = new User
            {
                UserId = dto.UserId,
                EmailId = dto.EmailId,
                BirthDate = dto.BirthDate,
                Address = dto.Address
            };

            // DAL call
            await _userRepository.UpdateAsync(user, ipList);
        }

        public async Task DeleteUserAsync(int userId)
        {
            await _userRepository.DeleteAsync(userId);
        }

        public async Task<List<UserDto>> GetAllUsersAsync()
        {
            var users = await _userRepository.GetAllAsync();
            return users.Select(u => new UserDto
            {
                UserId = u.UserId,
                UserName = u.UserName,
                EmailId = u.EmailId,
                BirthDate = u.BirthDate,
                Address = u.Address,
                AllowedIps = string.Join(", ", u.Ips.Select(ip => ip.IpAddress))
            }).ToList();
        }

        public async Task<UserDetailDto?> GetUserByIdAsync(int userId)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null)
                return null;

            return new UserDetailDto
            {
                UserId = user.UserId,
                UserName = user.UserName,
                EmailId = user.EmailId,
                BirthDate = user.BirthDate,
                Address = user.Address,
                CreatedDate = user.CreatedDate,
                IpAddresses = user.Ips.Select(ip => ip.IpAddress).ToList()
            };
        }
    }
}
