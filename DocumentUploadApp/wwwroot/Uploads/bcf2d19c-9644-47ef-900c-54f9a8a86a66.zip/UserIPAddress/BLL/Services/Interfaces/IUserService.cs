﻿using UserIPAddress.BLL.DTOs;

namespace UserIPAddress.BLL.Services.Interfaces
{
    public interface IUserService
    {
        Task<int> CreateUserAsync(UserCreateDto dto);
        Task UpdateUserAsync(UserUpdateDto dto);
        Task DeleteUserAsync(int userId);
        Task<List<UserDto>> GetAllUsersAsync();
        Task<UserDetailDto?> GetUserByIdAsync(int userId);
    }
}
