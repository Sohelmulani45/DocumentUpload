﻿using System.ComponentModel.DataAnnotations;

namespace UserIPAddress.DAL.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        public string UserName { get; set; } = null!;
        public string EmailId { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;
        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }
        public DateTime CreatedDate { get; set; }

        public List<UserIp> Ips { get; set; } = new();
    }
}
