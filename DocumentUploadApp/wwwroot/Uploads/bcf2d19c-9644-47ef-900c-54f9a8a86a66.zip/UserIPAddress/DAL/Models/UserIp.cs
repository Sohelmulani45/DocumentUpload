﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserIPAddress.DAL.Models
{
    public class UserIp
    {
        public int UserIpId { get; set; }
        public int UserId { get; set; }
        public string IpAddress { get; set; } = null!;
    }
}

