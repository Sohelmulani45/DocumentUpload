﻿using Dapper;
using System.Data;
using UserIPAddress.DAL.Infrastructure;
using UserIPAddress.DAL.Models;
using UserIPAddress.DAL.Repository.Interfaces;

namespace UserIPAddress.DAL.Repository.Implementations
{
    public class UserRepository : IUserRepository
    {
        private readonly IDbConnectionFactory _connectionFactory;

        public UserRepository(IDbConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> CreateAsync(User user, IEnumerable<string> ipList)
        {
            using var connection = _connectionFactory.CreateConnection();

            var parameters = new DynamicParameters();
            parameters.Add("@UserName", user.UserName);
            parameters.Add("@EmailId", user.EmailId);
            parameters.Add("@PasswordHash", user.PasswordHash);
            parameters.Add("@BirthDate", user.BirthDate);
            parameters.Add("@Address", user.Address);
            parameters.Add("@IpList", string.Join(",", ipList));

            var newId = await connection.ExecuteScalarAsync<int>(
                "dbo.spUser_Insert",
                parameters,
                commandType: CommandType.StoredProcedure);

            return newId;
        }

        public async Task UpdateAsync(User user, IEnumerable<string> ipList)
        {
            using var connection = _connectionFactory.CreateConnection();

            var parameters = new DynamicParameters();
            parameters.Add("@UserId", user.UserId);
            parameters.Add("@EmailId", user.EmailId);
            parameters.Add("@BirthDate", user.BirthDate);
            parameters.Add("@Address", user.Address);
            parameters.Add("@IpList", string.Join(",", ipList));

            await connection.ExecuteAsync(
                "dbo.spUser_Update",
                parameters,
                commandType: CommandType.StoredProcedure);
        }

        public async Task DeleteAsync(int userId)
        {
            using var connection = _connectionFactory.CreateConnection();

            var parameters = new DynamicParameters();
            parameters.Add("@UserId", userId);

            await connection.ExecuteAsync(
                "dbo.spUser_Delete",
                parameters,
                commandType: CommandType.StoredProcedure);
        }

        public async Task<List<User>> GetAllAsync()
        {
            using var connection = _connectionFactory.CreateConnection();

            // spUser_GetAll return karega: UserId, UserName, EmailId, BirthDate, Address, AllowedIps
            var rows = await connection.QueryAsync(
                "dbo.spUser_GetAll",
                commandType: CommandType.StoredProcedure);

            var list = new List<User>();

            foreach (var row in rows)
            {
                var user = new User
                {
                    UserId = row.UserId,
                    UserName = row.UserName,
                    EmailId = row.EmailId,
                    BirthDate = row.BirthDate,
                    Address = row.Address,
                    // PasswordHash, CreatedDate yahan zaroori nahi (listing ke liye)
                };

                string? allowedIps = row.AllowedIps;
                if (!string.IsNullOrWhiteSpace(allowedIps))
                {
                    user.Ips = allowedIps
                        .Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(ip => new UserIp
                        {
                            UserId = user.UserId,
                            IpAddress = ip.Trim()
                        })
                        .ToList();
                }

                list.Add(user);
            }

            return list;
        }

        public async Task<User?> GetByIdAsync(int userId)
        {
            using var connection = _connectionFactory.CreateConnection();

            using var multi = await connection.QueryMultipleAsync(
                "dbo.spUser_GetById",
                new { UserId = userId },
                commandType: CommandType.StoredProcedure);

            var user = await multi.ReadSingleOrDefaultAsync<User>();
            if (user == null)
                return null;

            var ips = (await multi.ReadAsync<UserIp>()).ToList();
            user.Ips = ips;

            return user;
        }
    }
}
