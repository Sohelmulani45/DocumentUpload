﻿using UserIPAddress.DAL.Models;

namespace UserIPAddress.DAL.Repository.Interfaces
{
    public interface IUserRepository
    {
        Task<int> CreateAsync(User user, IEnumerable<string> ipList);
        Task UpdateAsync(User user, IEnumerable<string> ipList);
        Task DeleteAsync(int userId);

        Task<List<User>> GetAllAsync();
        Task<User?> GetByIdAsync(int userId);
    }
}
