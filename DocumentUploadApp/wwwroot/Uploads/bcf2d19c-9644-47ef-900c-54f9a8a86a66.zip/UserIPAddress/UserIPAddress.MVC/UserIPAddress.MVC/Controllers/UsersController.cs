﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using UserIPAddress.MVC.Models;
using System.Net.Http;

namespace UserIPAddress.MVC.Controllers
{
    public class UsersController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public UsersController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        // GET: Users/Index
        public async Task<IActionResult> Index()
        {
            try
            {
                var httpClient = _httpClientFactory.CreateClient("ApiClient");
                var response = await httpClient.GetAsync("api/Users");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var users = JsonConvert.DeserializeObject<List<UserListViewModel>>(json);
                    return View(users ?? new List<UserListViewModel>());
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error loading users: {ex.Message}";
            }
            return View(new List<UserListViewModel>());
        }

        // GET: Users/Create
        public IActionResult Create()
        {
            return View(new UserCreateViewModel());
        }

        // POST: Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UserCreateViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var httpClient = _httpClientFactory.CreateClient("ApiClient");
                    var formData = new MultipartFormDataContent();
                    formData.Add(new StringContent(model.UserName), "UserName");
                    formData.Add(new StringContent(model.EmailId), "EmailId");
                    formData.Add(new StringContent(model.Password), "Password");
                    formData.Add(new StringContent(model.BirthDate?.ToString("yyyy-MM-dd") ?? ""), "BirthDate");
                    formData.Add(new StringContent(model.Address ?? ""), "Address");
                    formData.Add(new StringContent(model.IpList), "IpList");

                    var response = await httpClient.PostAsync("api/Users/register", formData);
                    if (response.IsSuccessStatusCode)
                    {
                        TempData["success"] = "User registered successfully!";
                        return RedirectToAction(nameof(Index));
                    }
                    else
                    {
                        var error = await response.Content.ReadAsStringAsync();
                        ModelState.AddModelError("", $"API Error: {response.StatusCode} - {error}");
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error: {ex.Message}");
                }
            }
            return View(model);
        }



        // GET: Users/Edit/5 ✅ FULLY FIXED VERSION
        public async Task<IActionResult> Edit(int id)
        {
            if (id <= 0)
            {
                TempData["error"] = "Invalid user ID";
                return RedirectToAction(nameof(Index));
            }

            var httpClient = _httpClientFactory.CreateClient("ApiClient");

            try
            {
                var response = await httpClient.GetAsync($"api/Users/{id}");
                if (!response.IsSuccessStatusCode)
                {
                    TempData["error"] = $"User not found (ID: {id}). Status: {response.StatusCode}";
                    return RedirectToAction(nameof(Index));
                }

                var json = await response.Content.ReadAsStringAsync();
                ViewBag.ResponseJson = json; // yahi tumko top pe dikh raha hai

                // API JSON → strong model
                var apiModel = JsonConvert.DeserializeObject<UserDetailApiModel>(json);
                if (apiModel == null)
                {
                    TempData["error"] = "Invalid data from API";
                    return RedirectToAction(nameof(Index));
                }

                var model = new UserUpdateViewModel
                {
                    UserId = apiModel.UserId,
                    UserName = apiModel.UserName,
                    EmailId = apiModel.EmailId,
                    BirthDate = apiModel.BirthDate,
                    Address = apiModel.Address,
                    IpList = string.Join(", ", apiModel.IpAddresses ?? new List<string>())
                };

                return View(model);
            }
            catch (Exception ex)
            {
                TempData["error"] = $"Error loading user {id}: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }




        // POST: Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(UserUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var httpClient = _httpClientFactory.CreateClient("ApiClient");
                    var formData = new MultipartFormDataContent();
                    formData.Add(new StringContent(model.UserId.ToString()), "UserId");
                    formData.Add(new StringContent(model.EmailId), "EmailId");
                    formData.Add(new StringContent(model.BirthDate?.ToString("yyyy-MM-dd") ?? ""), "BirthDate");
                    formData.Add(new StringContent(model.Address ?? ""), "Address");
                    formData.Add(new StringContent(model.IpList), "IpList");

                    var response = await httpClient.PutAsync("api/Users/update", formData);
                    if (response.IsSuccessStatusCode)
                    {
                        TempData["success"] = "User updated successfully!";
                        return RedirectToAction(nameof(Index));
                    }
                    else
                    {
                        var error = await response.Content.ReadAsStringAsync();
                        ModelState.AddModelError("", $"API Error: {response.StatusCode} - {error}");
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error: {ex.Message}");
                }
            }
            return View(model);
        }

        // POST: Users/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var httpClient = _httpClientFactory.CreateClient("ApiClient");
                var response = await httpClient.DeleteAsync($"api/Users/{id}");
                if (response.IsSuccessStatusCode)
                {
                    TempData["success"] = "User deleted successfully!";
                }
                else
                {
                    TempData["error"] = "Delete failed";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
