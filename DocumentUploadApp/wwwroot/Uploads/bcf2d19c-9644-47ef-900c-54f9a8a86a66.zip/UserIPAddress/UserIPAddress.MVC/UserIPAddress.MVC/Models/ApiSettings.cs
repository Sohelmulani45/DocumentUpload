﻿namespace UserIPAddress.MVC.Models
{
    public class ApiSettings
    {
        public string BaseUrl { get; set; } = null!;
    }
}
