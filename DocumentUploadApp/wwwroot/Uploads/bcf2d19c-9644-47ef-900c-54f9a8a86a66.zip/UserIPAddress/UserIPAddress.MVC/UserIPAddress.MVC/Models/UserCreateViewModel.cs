﻿using System.ComponentModel.DataAnnotations;

namespace UserIPAddress.MVC.Models
{
    public class UserCreateViewModel
    {
        [Required(ErrorMessage = "User name is required")]
        public string UserName { get; set; } = null!;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string EmailId { get; set; } = null!;

        [Required(ErrorMessage = "Password is required")]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters")]
        public string Password { get; set; } = null!;

        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }

        [Required(ErrorMessage = "At least one IP address is required")]
        public string IpList { get; set; } = null!;
    }
}
