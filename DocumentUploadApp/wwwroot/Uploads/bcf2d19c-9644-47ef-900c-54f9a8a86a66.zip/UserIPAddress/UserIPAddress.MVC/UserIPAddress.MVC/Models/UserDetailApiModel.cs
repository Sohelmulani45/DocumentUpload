﻿// Models/UserDetailApiModel.cs
namespace UserIPAddress.MVC.Models
{
    public class UserDetailApiModel
    {
        public int UserId { get; set; }           // userId
        public string UserName { get; set; } = ""; // userName
        public string EmailId { get; set; } = "";  // emailId
        public DateTime? BirthDate { get; set; }   // birthDate
        public string? Address { get; set; }       // address
        public List<string> IpAddresses { get; set; } = new(); // ipAddresses
    }
}
