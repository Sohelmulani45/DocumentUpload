﻿namespace UserIPAddress.MVC.Models
{
    public class UserListViewModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = null!;
        public string EmailId { get; set; } = null!;
        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }
        public string AllowedIps { get; set; } = null!;
    }
}
