﻿using System.ComponentModel.DataAnnotations;

namespace UserIPAddress.MVC.Models
{
    public class UserUpdateViewModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = null!;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string EmailId { get; set; } = null!;

        public DateTime? BirthDate { get; set; }
        public string? Address { get; set; }

        [Required(ErrorMessage = "At least one IP address is required")]
        public string IpList { get; set; } = null!;
    }
}
