using Microsoft.AspNetCore.Identity;
using UserIPAddress.BLL.Services.Interfaces;
using UserIPAddress.BLL.Services.Implementations;
using UserIPAddress.DAL.Infrastructure;
using UserIPAddress.DAL.Repository.Implementations;
using UserIPAddress.DAL.Repository.Interfaces;
using UserIPAddress.DAL.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Database connection factory
builder.Services.AddSingleton<IDbConnectionFactory>(provider =>
    new DbConnectionFactory(builder.Configuration.GetConnectionString("DefaultConnection")!));

// DAL layer registration
builder.Services.AddScoped<IUserRepository, UserRepository>();

// BLL layer registration
builder.Services.AddScoped<IUserService, UserService>();

// Password hasher for Identity (UserService ke liye)
builder.Services.AddScoped<IPasswordHasher<User>>(
    provider => new PasswordHasher<User>());

// CORS (frontend ke liye)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocalfront",
        policy =>
        {
            policy.WithOrigins("http://localhost:4200", "http://localhost:3000")
                  .AllowAnyMethod()
                  .AllowAnyHeader();
        });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowLocalfront");
app.UseAuthorization();
app.MapControllers();

app.Run();
